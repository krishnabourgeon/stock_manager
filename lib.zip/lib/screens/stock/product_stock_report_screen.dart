import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

class ProductStockReportScreen extends StatefulWidget {
  const ProductStockReportScreen({super.key});

  @override
  State<ProductStockReportScreen> createState() =>
      _ProductStockReportScreenState();
}

class _ProductStockReportScreenState
    extends State<ProductStockReportScreen> {
  final TextEditingController searchController =
      TextEditingController();

  List<Map<String, dynamic>> reportList = [
    {
      "code": "P001",
      "name": "Vegetable Seeds",
      "purchase": 100,
      "sold": 30,
      "stock": 70,
      "unit": "Nos"
    },
    {
      "code": "P002",
      "name": "Organic Manure",
      "purchase": 50,
      "sold": 10,
      "stock": 40,
      "unit": "Kg"
    },
  ];

  @override
  Widget build(BuildContext context) {
    int totalStock = reportList.fold(
      0,
      (sum, item) => sum + (item["stock"] as int),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text("Product Stock Report"),
        actions: [
          IconButton(
            onPressed: () async {
              await generatePdf();
            },
            icon: const Icon(Icons.picture_as_pdf),
          ),
          IconButton(
            onPressed: () async  {
              await sharePdfToWhatsApp();
            },
            icon: const Icon(Icons.share),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: "Search Product",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius:
                      BorderRadius.circular(10),
                ),
              ),
            ),

            const SizedBox(height: 15),

            // Row(
            //   children: [
            //     Expanded(
            //       child: Card(
            //         child: ListTile(
            //           title:
            //               const Text("Total Products"),
            //           subtitle: Text(
            //             reportList.length.toString(),
            //           ),
            //         ),
            //       ),
            //     ),
            //     Expanded(
            //       child: Card(
            //         child: ListTile(
            //           title: const Text("Stock"),
            //           subtitle:
            //               Text(totalStock.toString()),
            //         ),
            //       ),
            //     ),
            //   ],
            // ),

            // const SizedBox(height: 10),

            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  border:
                      TableBorder.all(color: Colors.grey),
                  headingRowColor:
                      MaterialStateProperty.all(
                    Colors.green,
                  ),
                  columns: const [
                    DataColumn(
                      label: Text(
                        "Sl No",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        "Code",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        "Product",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        "Purchased",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        "Sold",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        "Balance",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        "Unit",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                  rows: reportList
                      .asMap()
                      .entries
                      .map((entry) {
                    final index = entry.key;
                    final item = entry.value;

                    return DataRow(
                      cells: [
                        DataCell(
                          Text("${index + 1}"),
                        ),
                        DataCell(
                          Text(item["code"]),
                        ),
                        DataCell(
                          Text(item["name"]),
                        ),
                        DataCell(
                          Text(
                            item["purchase"]
                                .toString(),
                          ),
                        ),
                        DataCell(
                          Text(
                            item["sold"].toString(),
                          ),
                        ),
                        DataCell(
                          Text(
                            item["stock"]
                                .toString(),
                            style: const TextStyle(
                              color: Colors.green,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ),
                        DataCell(
                          Text(item["unit"]),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


  Future<File> _createPdfFile() async {
  final pdf = pw.Document();

  pdf.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4.landscape,
      build: (context) => [
        pw.Text(
          'Product Wise Stock Report',
          style: pw.TextStyle(
            fontSize: 18,
            fontWeight: pw.FontWeight.bold,
          ),
        ),

        pw.SizedBox(height: 20),

        pw.Table(
          border: pw.TableBorder.all(),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(
                color: PdfColors.green,
              ),
              children: [
                _headerCell('Sl No'),
                _headerCell('Code'),
                _headerCell('Product'),
                _headerCell('Purchased'),
                _headerCell('Sold'),
                _headerCell('Balance'),
                _headerCell('Unit'),
              ],
            ),

            ...reportList.asMap().entries.map(
              (entry) {
                final index = entry.key;
                final item = entry.value;

                return pw.TableRow(
                  children: [
                    _cell("${index + 1}"),
                    _cell(item["code"]),
                    _cell(item["name"]),
                    _cell(item["purchase"].toString()),
                    _cell(item["sold"].toString()),
                    _cell(item["stock"].toString()),
                    _cell(item["unit"]),
                  ],
                );
              },
            ),
          ],
        ),
      ],
    ),
  );

    final directory = await getTemporaryDirectory();

    final file = File(
      "${directory.path}/product_stock_report.pdf",
    );

    await file.writeAsBytes(
      await pdf.save(),
    );

    return file;
  }

  Future<void> generatePdf() async {
  final file = await _createPdfFile();

    await Printing.layoutPdf(
      onLayout: (_) async => file.readAsBytes(),
    );
  }

  Future<void> sharePdfToWhatsApp() async {
    final file = await _createPdfFile();

    await Share.shareXFiles(
      [XFile(file.path)],
      text: 'Product Wise Stock Report',
    );
  }

  pw.Widget _headerCell(String text) {
  return pw.Padding(
    padding: const pw.EdgeInsets.all(5),
    child: pw.Text(
      text,
      style: pw.TextStyle(
        color: PdfColors.white,
        fontWeight: pw.FontWeight.bold,
      ),
    ),
  );
}

pw.Widget _cell(String text) {
  return pw.Padding(
    padding: const pw.EdgeInsets.all(5),
    child: pw.Text(text),
  );
}
  
}